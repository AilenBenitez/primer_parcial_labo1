/*
 ============================================================================
 Name        : primer_parcial_labo.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "input.h"
#include "vehiculos.h"
#define VEHICULOS 20

int main(void) {

		int option;
		int flagDadoDeAlta=0;
		int idFounded;
		int order;


		eVehiculo vehiculo [VEHICULOS];

		initVehiculos(vehiculo, VEHICULOS );

		do
		{
			//Muestra el men�
			puts("---------------------------------");
			puts("1.ALTA VEHICULO");
			puts("2. MODIFICAR VEHICULO");
			puts("3. BAJA VEHICULO");
			puts("4. LISTAR VEHICULOS:");
			puts("5. LISTAR TIPOS");
			puts("6. ALTA HOJA DE SERVICIO:");
			puts("7. LISTAR HOJAS DE SERVICIO");
			puts("8. INFORMES");
			puts("9. SALIR");
			puts("---------------------------------");

			fflush(stdin);
			ingresoIntMinMax(&option,"", "Error, ingrese un numero valido: " , 1, 9);

			switch(option){
			case 1:

				flagDadoDeAlta=1;
				break;
			case 2:

				if(flagDadoDeAlta==1)
				{
					if(printVehiculos(vehiculo, VEHICULOS) != FALSE)
					{
						idFounded = ingresoInt("Ingrese el n�mero de ID del vehiculo a modificar: ", "Error. Ingrese un n�mero valido: ");
						if(findVehiculoById(vehiculo, VEHICULOS, idFounded) != FALSE)
						{
							  if(modifyVehiculo(vehiculo, VEHICULOS, idFounded) != FALSE)
							   {
								  puts("---------------------------------");
								  puts("�vehiculo modificado con �xito!");
								  puts("---------------------------------");
							   }
							   else
							   {
								  puts("---------------------------------");
								  puts("Error. �Algo sali� mal!");
								  puts("---------------------------------");
							  }
						}
						else
						{
							puts("---------------------------------");
							puts("Error. �vehiculo no encontrado!");
							puts("---------------------------------");
						}
					}
				}
				else
				{
					puts("---------------------------------");
					puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					puts("---------------------------------");
				}
				break;
			case 3:
				if(flagDadoDeAlta==1)
				{
					if(printvehiculos(vehiculos, VEHICULOS) != FALSE)
					{

						idFounded = ingresoInt("Ingrese el n�mero de ID del vehiculo a eliminar: ", "Error. Ingrese un n�mero valido: ");
						if(findServicioById(vehiculos, VEHICULOS, idFounded) != FALSE)
						{
							if(removeVehiculos(vehiculos, VEHICULOS, idFounded) != FALSE)
							{
								contvehiculos--;
								puts("---------------------------------");
								puts("Error. �vehiculo eliminado con �xito!");
								puts("---------------------------------");
							}
							else
							{
								puts("---------------------------------");
								puts("Error. �Algo sali� mal!");
								puts("---------------------------------");
							}
						}
						else
						{
							puts("---------------------------------");
							puts("Error. �vehiculo no encontrado!");
							puts("---------------------------------");
						}
					}
				}
				else
				{
					puts("---------------------------------");
					puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					puts("---------------------------------");
				}

				break;
			case 4:
				if(flagDadoDeAlta==1){
				}
				else{
					puts("---------------------------------");
					puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					puts("---------------------------------");
				}
				break;
			case 5:
				if(flagDadoDeAlta==1){

				}
				else{
					puts("---------------------------------");
					puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					puts("---------------------------------");
				}
				break;
			case 6:
			    if(flagDadoDeAlta==1){

			    }
			    else{
			    	puts("---------------------------------");
			    	puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
			    	puts("---------------------------------");
			    }
			 break;
			case 7:
				if(flagDadoDeAlta==1){

				}
				else{
					puts("---------------------------------");
					puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					puts("---------------------------------");
				}
				break;
			case 8:
				if(flagDadoDeAlta==1){

				}
				 else{
					 puts("---------------------------------");
					 puts("Error. �No existen vehiculos. Debe existir al menos un vehiculo para usar esta opci�n!");
					 puts("---------------------------------");
				}
			    break;

			}
		}while(option != 9);

	}
}

