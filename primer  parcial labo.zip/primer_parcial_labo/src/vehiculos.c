/*
 * vehiculos.c
 *
 *  Created on: 21 oct. 2022
 *      Author: Ail�n
 */
#include "vehiculos.h"
#include "input.h"

int initVehiculos(eVehiculo* list, int len)
{
	int status = FALSE;
	int i;

	if(list != NULL && len > 0) // Valida que el array exista y no se encuentre vacio
	{
		status = TRUE; // Sali� bien

		for(i = 0; i < len; i++)
		{
			list[i].isEmpty = TRUE; // Establece cada "pasajero" como LIBRE
		}
	}

	return status;
}

int addVehiculo(eVehiculo* list, int len, int id, int tipoid, int modelo, char descripcion[], char color[])
{
	int status = FALSE;
	int i;

	if(list != NULL && len > 0 && descripcion != NULL  && color != NULL) // Valida que el array exista Y no se encuentre vacio y que todos los datos sean llenados
	{
		for(i = 0; i < len; i++) // Recorre el array en busca de un espacio libre
		{
			if(list[i].isEmpty == TRUE) // Verifica s� el espacio se encuentra libre o no
			{
				list[i].isEmpty = FALSE;
				strcpy(list[i].descripcion, descripcion);
				strcpy(list[i].color, color);
				list[i].eVehiculo.idVehiculo= idVehiculo;
				list[i].eVehiculo.modelo= modelo;
				list[i].eVehiculo.tipoid= tipoid;
				status = TRUE; // Sali� bien
				break; // Una vez creado, deja de buscar y corta el bucle
			}
		}
	}

	return status;
}

int printVehiculos(Vehiculo* list, int len)
{
	int status = FALSE;
	int i;
	int cantidad = 0;

	if(list != NULL && len > 0){
		status = TRUE;

		puts("--------------------------------------");
		for(i = 0; i < len; i++){
			if(list[i].isEmpty == FALSE){

				printf("|id vehiculo: %4d| modelo: %-11s|color: %-11d|", eVehiculo.idVehiculo, eVehiculo.modelo, eVehiculo.color);

					switch(eVehiculo.tipoId)
					{
						case 1:
							printf("%-10s|\n", "(1-SEDAN 3PTAS");
						break;

						case 2:
							printf("%-10s|\n", "2-SEDAN 5PTAS,");
						break;

						case 3:
							printf("%-10s|\n", "3-CAMIONETA)");
						break;
					}


			  cantidad++;
			  }
		}
		puts("--------------------------------------");
	}

	return status;
}

int findVehiculoById(Vehiculo* list, int len, int id)
{
	int status = FALSE;
	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && list[i].idVehiculo == id)
			{
				status = i;
			}
		}
	}

	return status;
}
