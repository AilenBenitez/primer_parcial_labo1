/*
 * vehiculos.h
 *
 *  Created on: 21 oct. 2022
 *      Author: Ail�n
 */

#ifndef VEHICULOS_H_
#define VEHICULOS_H_

typedef struct
{
	int idTipo;
	char descripcion[LEN_CHAR];
}eTipo;

typedef struct
{
	int tipoid;
	char descripcion[LEN_CHAR];
	int modelo;
	char color[10];
	int tipoId;
	int isEmpty;
}eVehiculo;


#endif /* VEHICULOS_H_ */
